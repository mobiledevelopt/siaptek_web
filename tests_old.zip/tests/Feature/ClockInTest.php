<?php

namespace Tests\Feature;

use App\Constants\ErrorCode;
use App\Exceptions\ApiException;
use App\Models\AttendancesPegawai;
use App\Models\ConfigPotTpp;
use App\Models\Dinas;
use App\Models\JadwalApel;
use App\Models\JamAbsen;
use App\Models\Jml_hari_kerja;
use App\Models\Pegawai;
use App\Services\Attendance\AttendanceService;
use Carbon\Carbon;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Support\Facades\Cache;
use Tests\TestCase;

class ClockInTest extends TestCase
{

    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        Cache::flush();

        JamAbsen::insert([
            'id' => 1,
            'title' => 'Senin - Kamis',
            'min_masuk' => '07:00',
            'jam_masuk' => '08:00',
            'max_masuk' => '10:00',
            'min_pulang' => '15:00',
            'jam_pulang' => '15:00',
            'max_pulang' => '18:00'
        ], [
            'id' => 2,
            'title' => 'Jumat',
            'min_masuk' => '07:00',
            'jam_masuk' => '08:00',
            'max_masuk' => '10:00',
            'min_pulang' => '15:30',
            'jam_pulang' => '15:30',
            'max_pulang' => '18:00'
        ]);

        ConfigPotTpp::insert([
            [
                'id' => 1,
                'title' => 'Telat 1',
                'dari_meni' => 1,
                'sampai_menit' => 30,
                'persentase_potongan' => 15,
                'group' => 'masuk'
            ],
            [
                'id' => 2,
                'title' => 'Telat 2',
                'dari_meni' => 31,
                'sampai_menit' => 60,
                'persentase_potongan' => 30,
                'group' => 'masuk'
            ],
            [
                'id' => 3,
                'title' => 'Telat 3',
                'dari_meni' => 61,
                'sampai_menit' => 90,
                'persentase_potongan' => 45,
                'group' => 'masuk'
            ],
            [
                'id' => 4,
                'title' => 'Telat 4',
                'dari_meni' => 91,
                'sampai_menit' => 120,
                'persentase_potongan' => 60,
                'group' => 'masuk'
            ],
            [
                'id' => 5,
                'title' => 'Tidak Absen Pulang (PSW)',
                'dari_meni' => 0,
                'sampai_menit' => 0,
                'persentase_potongan' => 20,
                'group' => 'pulang'
            ],
            [
                'id' => 6,
                'title' => 'Izin Dengan Keterangan',
                'dari_meni' => 0,
                'sampai_menit' => 0,
                'persentase_potongan' => 50,
                'group' => 'izin'
            ],
            [
                'id' => 7,
                'title' => 'Dinas Luar',
                'dari_meni' => 0,
                'sampai_menit' => 0,
                'persentase_potongan' => 0,
                'group' => 'izin'
            ]
        ]);

        Jml_hari_kerja::insert([
            'bulan' => date('m'),
            'tahun' => date('Y'),
            'jml_hari_kerja' => 22
        ]);

        Dinas::create([
            'id' => 1,
            'nama_dinas' => 'Dinas A',
            'latitude' => -6.2088,
            'longitude' => 106.8456,
            'latitude_2' => -6.2088,
            'longitude_2' => 106.8456
        ]);

        JadwalApel::insert(
            [
                'dinas_id' => 1,
                'hari' => '1',
                'apel_pagi' => '1',
                'apel_sore' => '0',
                'jam_apel_pagi' => '08:00',
                'max_apel_pagi' => '08:15',
                'jam_apel_sore' => null,
                'max_apel_sore' => null,
                'latitude' => -6.2088,
                'longitude' => 106.8456,
                'latitude_2' => -6.2088,
                'longitude_2' => 106.8456
            ],
            [
                'dinas_id' => 1,
                'hari' => '2',
                'apel_pagi' => '1',
                'apel_sore' => '0',
                'jam_apel_pagi' => '08:00',
                'max_apel_pagi' => '08:15',
                'jam_apel_sore' => null,
                'max_apel_sore' => null,
                'latitude' => -6.2088,
                'longitude' => 106.8456,
                'latitude_2' => -6.2088,
                'longitude_2' => 106.8456
            ],
            [
                'dinas_id' => 1,
                'hari' => '3',
                'apel_pagi' => '1',
                'apel_sore' => '0',
                'jam_apel_pagi' => '08:00',
                'max_apel_pagi' => '08:15',
                'jam_apel_sore' => null,
                'max_apel_sore' => null,
                'latitude' => -6.2088,
                'longitude' => 106.8456,
                'latitude_2' => -6.2088,
                'longitude_2' => 106.8456
            ],
            [
                'dinas_id' => 1,
                'hari' => '4',
                'apel_pagi' => '1',
                'apel_sore' => '0',
                'jam_apel_pagi' => '08:00',
                'max_apel_pagi' => '08:15',
                'jam_apel_sore' => null,
                'max_apel_sore' => null,
                'latitude' => -6.2088,
                'longitude' => 106.8456,
                'latitude_2' => -6.2088,
                'longitude_2' => 106.8456
            ],
            [
                'dinas_id' => 1,
                'hari' => '5',
                'apel_pagi' => '1',
                'apel_sore' => '1',
                'jam_apel_pagi' => '08:00',
                'max_apel_pagi' => '08:15',
                'jam_apel_sore' => '16:00',
                'max_apel_sore' => '16:15',
                'latitude' => -6.2088,
                'longitude' => 106.8456,
                'latitude_2' => -6.2088,
                'longitude_2' => 106.8456
            ],
        );
    }

    public function test_clock_in_telat_levels()
    {
        $service = new AttendanceService();
        $user = Pegawai::factory()->create(['tpp' => 1000000, 'dinas_id' => 1]);

        $telatTests = [
            '2026-03-04 08:10:00' => ['Telat 1', 2727],
            '2026-03-04 08:45:00' => ['Telat 2', 5454],
            '2026-03-04 09:20:00' => ['Telat 3', 8181],
            '2026-03-04 09:50:00' => ['Telat 4', 10909],
        ];

        foreach ($telatTests as $time => [$expectedStatus, $expectedPotongan]) {
            Carbon::setTestNow($time);
            $user->fresh(); // pastikan state bersih

            // Hapus data absen sebelumnya
            AttendancesPegawai::where('pegawai_id', $user->id)->delete();

            $result = $service->clockIn($user);

            $this->assertDatabaseHas('attendances_pegawai', [
                'pegawai_id' => $user->id,
                'status_masuk' => $expectedStatus
            ]);

            $this->assertGreaterThan(0, $result->menit_telat_masuk);
            // cek potongan
            $this->assertEquals($expectedPotongan, $result->potongan_absen_masuk);
        }
    }

    public function test_double_clock_in_throws_exception()
    {
        $this->setHariKerja();

        $user = Pegawai::factory()->create(['tpp' => 1000000, 'dinas_id' => 1]);
        $service = new AttendanceService();
        
        $service->clockIn($user);

        try {
            $service->clockIn($user);
            $this->fail('Seharusnya gagal karena sudah presensi masuk');
        } catch (ApiException $e) {
            $this->assertEquals(ErrorCode::ALREADY_CLOCKED_IN, $e->getErrorCode());
        }

    }

    public function test_clock_in_before_jam_masuk_throws_exception()
    {
        $this->setSebelumJamMasuk();

        $user = Pegawai::factory()->create(['tpp' => 1000000, 'dinas_id' => 1]);

        try {
            (new AttendanceService())->clockIn($user);
            $this->fail('Seharusnya gagal karena sebelum jam masuk');
        } catch (ApiException $e) {
            $this->assertStringContainsString('Minimal Jam Presensi Masuk', $e->getMessage());
        }
    }

    public function test_clock_in_after_batas_jam_masuk_throws_exception()
    {
        $this->setSetelahBatasMasuk();

        $user = Pegawai::factory()->create(['tpp' => 1000000, 'dinas_id' => 1]);

        try {
            (new AttendanceService())->clockIn($user);
            $this->fail('Seharusnya gagal karena melebihi batas jam masuk');
        } catch (ApiException $e) {
            $this->assertEquals('Melebihi batas jam masuk', $e->getMessage());
        }
    }

    public function test_clock_in_hari_libur_throws_exception()
    {
        $this->setHariLibur();

        $user = Pegawai::factory()->create(['tpp' => 1000000, 'dinas_id' => 1]);

        try {
            (new AttendanceService())->clockIn($user);
            $this->fail('Seharusnya gagal karena hari libur');
        } catch (ApiException $e) {
            $this->assertEquals(ErrorCode::WEEKEND, $e->getErrorCode());
        }

    }

    public function test_clock_in_without_jml_hari_kerja()
    {
        $this->setHariKerja();

        $user = Pegawai::factory()->create([
            'tpp' => 1000000,
            'dinas_id' => 1
        ]);

        Jml_hari_kerja::truncate();

        $this->assertApiException(
            fn() => (new AttendanceService())->clockIn($user),
            ErrorCode::WORKDAY_NOT_CONFIGURED
        );
    }

}
