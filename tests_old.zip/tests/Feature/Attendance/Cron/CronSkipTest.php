<?php

namespace Tests\Feature\Cron;

use App\Models\AttendancesPegawai;
use App\Services\Attendance\AttendanceCronHandler;
use Carbon\Carbon;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use Tests\Traits\CronTestSetup;

class CronSkipTest extends TestCase
{
    use RefreshDatabase, CronTestSetup;

    protected function setUp(): void
    {
        parent::setUp();
        $this->setUpCron();
    }

    public function test_should_skip_cron_on_weekend()
    {
        // Minggu
        Carbon::setTestNow('2026-03-08 08:00:00');

        $user = $this->createUser();

        $this->runCron();

        $this->assertDatabaseMissing('attendances_pegawai', [
            'pegawai_id' => $user->id,
        ]);
    }

    public function test_cron_should_skip_when_status_izin()
    {
        $user = $this->createUser();

        $absen = AttendancesPegawai::create([
            'pegawai_id' => $user->id,
            'dinas_id' => 1,
            'date_attendance' => now()->toDateString(),
            'incoming_time' => '00:00:00',
            'outgoing_time' => '00:00:00',
            'status' => 'izin',
            'total_potongan_tpp' => 5000,
            'tpp_diterima' => 10000,
        ]);

        $this->runCron();

        $absen->refresh();

        // ✅ tidak berubah
        $this->assertEquals('izin', $absen->status);
        $this->assertEquals(5000, $absen->total_potongan_tpp);
        $this->assertEquals(10000, $absen->tpp_diterima);
    }

}
