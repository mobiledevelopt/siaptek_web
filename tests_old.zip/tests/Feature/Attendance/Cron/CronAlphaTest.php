<?php

namespace Tests\Feature\Cron;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use Tests\Traits\CronTestSetup;

class CronAlphaTest extends TestCase
{
    use RefreshDatabase, CronTestSetup;

    protected function setUp(): void
    {
        parent::setUp();
        $this->setUpCron();
    }

    public function test_should_mark_alpha_when_user_not_clock_in()
    {
        $this->setHariKerja();

        $user = $this->createUser();

        $this->runCron();

        $this->assertDatabaseHas('attendances_pegawai', [
            'pegawai_id' => $user->id,
            'status' => 'Tidak Masuk'
        ]);
    }

}
