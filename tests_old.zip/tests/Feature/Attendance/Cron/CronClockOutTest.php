<?php

namespace Tests\Feature\Cron;

use App\Models\Jml_hari_kerja;
use App\Services\Attendance\AttendanceService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use Tests\Traits\CronTestSetup;

class CronClockOutTest extends TestCase
{
    use RefreshDatabase, CronTestSetup;

    protected function setUp(): void
    {
        parent::setUp();
        $this->setUpCron();
    }

    public function test_should_mark_no_clock_out_when_user_does_not_clock_out()
    {
        $this->setHariKerja('08:05:00');

        $user = $this->createUser();

        (new AttendanceService())->clockIn($user);

        $this->setHariKerja('20:00:00');

        $this->runCron();

        $this->assertDatabaseHas('attendances_pegawai', [
            'pegawai_id' => $user->id,
            'status_pulang' => 'Tidak Absen Pulang (PSW)'
        ]);
    }

}
