<?php

namespace Tests\Feature\Cron;

use App\Services\Attendance\AttendanceService;
use Carbon\Carbon;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use Tests\Traits\CronTestSetup;

class CronApelTest extends TestCase
{
    use RefreshDatabase, CronTestSetup;

    protected function setUp(): void
    {
        parent::setUp();
        $this->setUpCron();
    }

    public function test_should_mark_no_apel_pagi_when_user_misses_apel()
    {
        // pagi (lewat jam apel)
        $this->setHariKerja('09:00:00');

        $user = $this->createUser();

        // user hanya clock in
        (new AttendanceService())->clockIn($user);

        // jalankan cron
        $this->runCron();

        // assert
        $this->assertDatabaseHas('attendances_pegawai', [
            'pegawai_id' => $user->id,
            'status_apel_pagi' => 'Tidak Apel'
        ]);
    }
    
    public function test_should_mark_no_apel_sore_on_friday()
    {
        Carbon::setTestNow('2026-03-06 08:05:00'); // Jumat

        $user = $this->createUser();

        (new AttendanceService())->clockIn($user);

        Carbon::setTestNow('2026-03-06 18:00:00');

        $this->runCron();

        $this->assertDatabaseHas('attendances_pegawai', [
            'pegawai_id' => $user->id,
            'status_apel_sore' => 'Tidak Apel'
        ]);
    }

}
