<?php

namespace Tests\Feature\Cron;

use App\Models\AttendancesPegawai;
use App\Services\Attendance\AttendanceCronHandler;
use App\Services\Attendance\AttendanceService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use Tests\Traits\CronTestSetup;

class CronIdempotentTest extends TestCase
{
    use RefreshDatabase, CronTestSetup;

    protected function setUp(): void
    {
        parent::setUp();
        $this->setUpCron();
    }

    // public function test_cron_idempotent_tidak_double_potongan()
    // {
    //     $this->setHariKerja('08:05:00');

    //     $user = $this->createUser();

    //     (new AttendanceService())->clockIn($user);

    //     $this->setHariKerja('20:00:00');

    //     // run pertama
    //     $this->runCron();

    //     $first = AttendancesPegawai::first()->total_potongan_tpp;

    //     // run kedua
    //     $this->runCron();

    //     $second = AttendancesPegawai::first()->total_potongan_tpp;

    //     $this->assertEquals($first, $second);
    // }

    public function test_cron_idempotent_tidak_double_potongan()
    {
        $this->setHariKerja('08:05:00');

        $user = $this->createUser();

        (new AttendanceService())->clockIn($user);

        $this->setHariKerja('20:00:00');

        $this->runCron();
        $first = AttendancesPegawai::first()->total_potongan_tpp;

        $this->runCron();
        $second = AttendancesPegawai::first()->total_potongan_tpp;

        $this->assertEquals($first, $second);

        // tambahan penting
        $this->assertNotEquals(0, $first);
    }

    public function test_cron_idempotent_for_izin()
    {
        $user = $this->createUser();

        $absen = AttendancesPegawai::create([
            'pegawai_id' => $user->id,
            'dinas_id' => 1,
            'date_attendance' => now()->toDateString(),
            'incoming_time' => '00:00:00',
            'outgoing_time' => '00:00:00',
            'status' => 'izin',
            'total_potongan_tpp' => 6000,
            'tpp_diterima' => 9000,
        ]);

        /**
         * ini high-level execution (real scenario)
         */
        // $this->runCron();
        // $this->runCron();

        /** 
         * Ini unit-level execution (isolated)
         */
        $handler = new AttendanceCronHandler();
        // // run 2x
        $handler->handle($user, $this->mockConfig());
        $handler->handle($user, $this->mockConfig());

        $absen->refresh();

        // ✅ tetap sama
        $this->assertEquals(6000, $absen->total_potongan_tpp);
        $this->assertEquals(9000, $absen->tpp_diterima);
    }

    protected function mockConfig()
    {
        return [
            'jmlHariKerja' => 22,
            'configTpp' => [
                'alfa' => (object)[
                    'id' => 1,
                    'title' => 'Alpha',
                    'persentase_potongan' => 100
                ],
                'pulang' => (object)[
                    'title' => 'Tidak Absen Pulang',
                    'persentase_potongan' => 100
                ],
                'apel' => (object)[
                    'title' => 'Tidak Apel',
                    'persentase_potongan' => 100
                ]
            ]
        ];
    }
}
