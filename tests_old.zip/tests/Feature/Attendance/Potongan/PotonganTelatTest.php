<?php

namespace Tests\Feature\Potongan;

use App\Services\Attendance\AttendanceService;
use Carbon\Carbon;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use Tests\Traits\CronTestSetup;

class PotonganTelatTest extends TestCase
{
    use RefreshDatabase, CronTestSetup;

    protected function setUp(): void
    {
        parent::setUp();
        $this->setUpCron();
    }

    public function test_should_calculate_exact_potongan_telat_1()
    {
        $this->setHariKerja('08:10:00'); // dari menit 1 - 30

        $user = $this->createUser();

        $result = (new AttendanceService())->clockIn($user);

        // tunjangan per hari = 1.000.000 / 22  * 40% = 18181.81
        // potongan 15% = 18181.81 * 15% = 2727.27

        $this->assertEquals(2727, $result->potongan_absen_masuk);
    }

    public function test_should_calculate_exact_potongan_telat_2()
    {
        $this->setHariKerja('08:31:00'); // dari menit 31 - 60

        $user = $this->createUser();

        $result = (new AttendanceService())->clockIn($user);

        // tunjangan per hari = 1.000.000 / 22  * 40% = 18181.81
        // potongan 30% = 18181.81 * 30% = 5454.54

        $this->assertEquals(5454, $result->potongan_absen_masuk);
    }

    public function test_should_calculate_exact_potongan_telat_3()
    {
        $this->setHariKerja('09:10:00'); // dari menit 61 - 90

        $user = $this->createUser();

        $result = (new AttendanceService())->clockIn($user);

        // tunjangan per hari = 1.000.000 / 22  * 40% = 18181.81
        // potongan 45% = 18181.81 * 45% = 8181.81

        $this->assertEquals(8181, $result->potongan_absen_masuk);
    }

    public function test_should_calculate_exact_potongan_telat_4()
    {
        $this->setHariKerja('09:31:00'); // dari menit > 90

        $user = $this->createUser();

        $result = (new AttendanceService())->clockIn($user);

        // tunjangan per hari = 1.000.000 / 22  * 40% = 18181.81
        // potongan 60% = 18181.81 * 60% = 10909.09

        $this->assertEquals(10909, $result->potongan_absen_masuk);
    }

    public function test_should_calculate_exact_potongan_not_apel_pagi()
    {
        $this->setHariKerja('08:00:00');

        $user = $this->createUser();

        $service = new AttendanceService();

        $service->clockIn($user);

        $this->setHariKerja('20:00:00');

        $this->runCron();

        // 18.181 * 40% * 20% = 3636.36
        $this->assertDatabaseHas('attendances_pegawai', [
            'pegawai_id' => $user->id,
            'potongan_tidak_apel_pagi' => 3636
        ]);
    }

    public function test_should_calculate_exact_potongan_not_apel_sore()
    {
        Carbon::setTestNow('2026-03-06 08:00:00'); // Jumat

        $user = $this->createUser();

        $service = new AttendanceService();

        $service->clockIn($user);

        Carbon::setTestNow('2026-03-06 20:00:00');

        $this->runCron();

        // 18.181 * 40% * 10% = 1818.18
        $this->assertDatabaseHas('attendances_pegawai', [
            'pegawai_id' => $user->id,
            'potongan_tidak_apel_sore' => 1818
        ]);
    }

    public function test_should_calculate_exact_potongan_not_apel_pagi_and_sore()
    {
        Carbon::setTestNow('2026-03-06 08:00:00'); // Jumat

        $user = $this->createUser();

        $service = new AttendanceService();

        $service->clockIn($user);

        Carbon::setTestNow('2026-03-06 20:00:00');

        $this->runCron();

        // 18.181 * 40% * 10% = 1818.18
        $this->assertDatabaseHas('attendances_pegawai', [
            'pegawai_id' => $user->id,
            'potongan_tidak_apel_pagi' => 1818,
            'potongan_tidak_apel_sore' => 1818
        ]);
    }

    public function test_should_calculate_exact_potongan_tidak_clock_out()
    {
        $this->setHariKerja('08:05:00');

        $user = $this->createUser();

        $service = new AttendanceService();

        $service->clockIn($user);

        $this->setHariKerja('20:00:00');

        $this->runCron();

        // 18.181 * 20% = 3.636
        $this->assertDatabaseHas('attendances_pegawai', [
            'pegawai_id' => $user->id,
            'potongan_absen_pulang' => 3636
        ]);
    }

    public function test_should_accumulate_multiple_penalties_in_one_day()
    {
        // Jumat (biar kena apel pagi + sore)
        Carbon::setTestNow('2026-03-06 09:00:00');

        $user = $this->createUser([
            'tpp' => 1000000
        ]);

        $service = new AttendanceService();

        // 👉 Clock in telat (09:00 → Telat 2)
        $service->clockIn($user);

        // ❌ Tidak apel sama sekali

        // ❌ Tidak clock out

        // 👉 Jalankan cron di malam hari
        Carbon::setTestNow('2026-03-06 20:00:00');
        $this->runCron();

        $absen = \App\Models\AttendancesPegawai::where('pegawai_id', $user->id)->first();

        // 🔥 Expected calculation
        $tunjangan = round(1000000 / 22); // 45455

        $telat = round($tunjangan * 0.4 * 0.30); // Telat 2 = 30%
        $apelPagi = round($tunjangan * 0.4 * 0.10); // Jumat dibagi 2
        $apelSore = round($tunjangan * 0.4 * 0.10);
        $noClockOut = round($tunjangan * 0.4 * 0.20);

        $expectedTotal = round($telat + $apelPagi + $apelSore + $noClockOut);


        // ✅ ASSERT
        $this->assertEquals($expectedTotal, $absen->total_potongan_tpp);

        $this->assertEquals(
            round($tunjangan - $expectedTotal),
            $absen->tpp_diterima
        );
    }
}
