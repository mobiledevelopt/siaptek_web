<?php

namespace Tests\Feature\Potongan;

use Tests\TestCase;
use App\Models\AttendancesPegawai;
use App\Models\Pegawai;
use App\Services\Attendance\AttendanceCronHandler;
use App\Services\Attendance\Payroll\PayrollCalculator;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Carbon\Carbon;
use Tests\Traits\CronTestSetup;

class AttendanceMatrixTest extends TestCase
{
    use RefreshDatabase, CronTestSetup;

    protected $cron;
    protected $calculator;

    protected function setUp(): void
    {
        parent::setUp();

        $this->setUpCron();

        $this->cron = new AttendanceCronHandler();
        $this->calculator = new PayrollCalculator();

        Carbon::setTestNow('2026-03-28 18:00:00'); // sore → semua rule aktif
    }

    /** @test */
    public function attendance_matrix_true_production_simulation()
    {
        $pegawaiList = Pegawai::factory()->count(3)->create([
            'tpp' => 18181,
        ]);

        $statuses = ['Masuk', 'Tidak Masuk', 'izin', 'cuti', 'Dinas Luar'];
        $clockInOptions = [true, false];
        $clockOutOptions = [true, false];
        $apelPagiOptions = [true, false];
        $apelSoreOptions = [true, false];

        $config = [
            'jmlHariKerja' => 5,
            'configTpp' => \App\Services\Attendance\AttendanceCache::potonganTpp()->keyBy('group'),
        ];

        $matrixCount = 0;

        foreach ($pegawaiList as $pegawai) {
            foreach ($statuses as $status) {
                foreach ($clockInOptions as $hasClockIn) {
                    foreach ($clockOutOptions as $hasClockOut) {
                        foreach ($apelPagiOptions as $apelPagi) {
                            foreach ($apelSoreOptions as $apelSore) {

                                $matrixCount++;

                                // 1️⃣ Create attendance (RAW condition)
                                $absen = AttendancesPegawai::create([
                                    'pegawai_id' => $pegawai->id,
                                    'date_attendance' => today(),
                                    'incoming_time' => $hasClockIn ? '08:00:00' : null,
                                    'outgoing_time' => $hasClockOut ? '17:00:00' : null,
                                    'apel_pagi_at' => $apelPagi ? now() : null,
                                    'apel_sore_at' => $apelSore ? now() : null,
                                    'status' => $status,
                                ]);

                                // 2️⃣ Expected (pure calculator)
                                $expected = $this->calculator->calculate($absen, $pegawai, $config);

                                $expectedTotal = (int) round($expected['total_potongan_tpp'] ?? 0);
                                $expectedDiterima = (int) round($expected['tpp_diterima'] ?? $pegawai->tpp);

                                // 3️⃣ RUN REAL CRON 🔥
                                $this->cron->handle($pegawai);

                                // 4️⃣ Ambil hasil DB setelah cron
                                $fresh = AttendancesPegawai::find($absen->id);

                                // 5️⃣ ASSERT CORE PAYROLL
                                $this->assertEquals(
                                    $expectedTotal,
                                    $fresh->total_potongan_tpp,
                                    "Mismatch total potongan"
                                );

                                $this->assertEquals(
                                    $expectedDiterima,
                                    $fresh->tpp_diterima,
                                    "Mismatch tpp diterima"
                                );

                                // 6️⃣ ASSERT STATUS (CRON EFFECT)
                                if (!$hasClockOut) {
                                    $this->assertNotNull($fresh->status_pulang);
                                }

                                if (!$apelPagi) {
                                    $this->assertNotNull($fresh->status_apel_pagi);
                                }

                                if (!$apelSore && now()->dayOfWeekIso == 5) {
                                    $this->assertNotNull($fresh->status_apel_sore);
                                }

                                // 7️⃣ IDEMPOTENCY TEST 🔥
                                $firstTotal = $fresh->total_potongan_tpp;

                                $this->cron->handle($pegawai); // run again

                                $fresh2 = AttendancesPegawai::find($absen->id);

                                $this->assertEquals(
                                    $firstTotal,
                                    $fresh2->total_potongan_tpp,
                                    "Cron is NOT idempotent"
                                );
                            }
                        }
                    }
                }
            }
        }

        echo "✅ Production matrix executed {$matrixCount} cases\n";
    }

    /** @test */
    public function attendance_matrix_should_match_calculator()
    {
        $pegawai = Pegawai::factory()->create([
            'tpp' => 18181,
        ]);

        $statuses = ['Masuk', 'Tidak Masuk', 'izin', 'cuti', 'Dinas Luar'];
        $bool = [true, false];

        $config = [
            'jmlHariKerja' => 5,
            'configTpp' => \App\Services\Attendance\AttendanceCache::potonganTpp()->keyBy('group'),
        ];

        foreach ($statuses as $status) {
            foreach ($bool as $in) {
                foreach ($bool as $out) {
                    foreach ($bool as $apelPagi) {
                        foreach ($bool as $apelSore) {

                            $absen = AttendancesPegawai::create([
                                'pegawai_id' => $pegawai->id,
                                'date_attendance' => today(),
                                'incoming_time' => $in ? '08:00:00' : null,
                                'outgoing_time' => $out ? '17:00:00' : null,
                                'apel_pagi_at' => $apelPagi ? now() : null,
                                'apel_sore_at' => $apelSore ? now() : null,
                                'status' => $status,
                            ]);

                            $expected = $this->calculator->calculate($absen, $pegawai, $config);

                            $this->assertIsArray($expected);
                            $this->assertArrayHasKey('total', $expected);
                            $this->assertArrayHasKey('diterima', $expected);
                        }
                    }
                }
            }
        }
    }

    /** @test */
    public function cron_result_must_equal_calculator()
    {
        $pegawai = Pegawai::factory()->create([
            'tpp' => 18181,
        ]);

        $absen = AttendancesPegawai::create([
            'pegawai_id' => $pegawai->id,
            'date_attendance' => today(),
            'incoming_time' => '08:30:00',
            'outgoing_time' => null,
            'apel_pagi_at' => null,
            'apel_sore_at' => null,
            'status' => 'Masuk',
        ]);

        $config = [
            'jmlHariKerja' => 5,
            'configTpp' => \App\Services\Attendance\AttendanceCache::potonganTpp()->keyBy('group'),
        ];

        $expected = $this->calculator->calculate($absen, $pegawai, $config);

        $this->runCron();

        $fresh = AttendancesPegawai::find($absen->id);

        $this->assertEquals($expected['total'], $fresh->total_potongan_tpp);
        $this->assertEquals($expected['diterima'], $fresh->tpp_diterima);
    }

    /** @test */
    public function cron_should_be_idempotent()
    {
        $pegawai = Pegawai::factory()->create([
            'tpp' => 18181,
        ]);

        $absen = AttendancesPegawai::create([
            'pegawai_id' => $pegawai->id,
            'date_attendance' => today(),
            'incoming_time' => null,
            'outgoing_time' => null,
            'apel_pagi_at' => null,
            'apel_sore_at' => null,
            'status' => 'Masuk',
        ]);

        $this->runCron();

        $first = AttendancesPegawai::first();

        $this->runCron();

        $second = AttendancesPegawai::first();

        $this->assertEquals($first->total_potongan_tpp, $second->total_potongan_tpp);
        $this->assertEquals($first->tpp_diterima, $second->tpp_diterima);
    }
}
