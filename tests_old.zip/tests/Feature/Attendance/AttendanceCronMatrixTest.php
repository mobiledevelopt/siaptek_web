<?php

namespace Tests\Feature\Attendance;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Services\Attendance\AttendanceCronHandler;
use App\Models\User;
use App\Models\AttendancesPegawai;
use Tests\Traits\CronTestSetup;

class AttendanceCronMatrixTest extends TestCase
{
    use RefreshDatabase, CronTestSetup;

    protected function setUp(): void
    {
        parent::setUp();
        $this->setUpCron();
    }

    /** @test */
    public function baseline_no_penalty()
    {
        $user = $this->createUser();

        AttendancesPegawai::create([
            'pegawai_id' => $user->id,
            'dinas_id' => $user->dinas_id,
            'date_attendance' => today()->toDateString(),
            'incoming_time' => '08:00:00',
            'outgoing_time' => '17:00:00',

            // 🔥 IMPORTANT: lock status
            'status_masuk' => 'hadir',
            'status_pulang' => 'hadir',
            'status_apel' => 'hadir',
        ]);

        app(\App\Services\Attendance\AttendanceCronService::class)->run(
            fn($q) => $q->where('id', $user->id)
        );

        $absen = AttendancesPegawai::where('pegawai_id', $user->id)
            ->where('date_attendance', today()->toDateString())
            ->first();

            
        $this->assertNotNull($absen);

        $this->assertEquals(0, $absen->total_potongan_tpp);
    }
}
