<?php

namespace Tests\Feature;

use App\Constants\ErrorCode;
use App\Exceptions\ApiException;
use App\Models\AttendancesPegawai;
use App\Models\ConfigPotTpp;
use App\Models\Dinas;
use App\Models\JadwalApel;
use App\Models\JamAbsen;
use App\Models\Jml_hari_kerja;
use App\Models\Pegawai;
use App\Services\Attendance\AttendanceService;
use Carbon\Carbon;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Support\Facades\Cache;
use Tests\TestCase;

class ClockOutTest extends TestCase
{

    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        Cache::flush();

        JamAbsen::insert([
            'id' => 1,
            'title' => 'Senin - Kamis',
            'min_masuk' => '07:00',
            'jam_masuk' => '08:00',
            'max_masuk' => '10:00',
            'min_pulang' => '15:00',
            'jam_pulang' => '15:00',
            'max_pulang' => '18:00'
        ], [
            'id' => 2,
            'title' => 'Jumat',
            'min_masuk' => '07:00',
            'jam_masuk' => '08:00',
            'max_masuk' => '10:00',
            'min_pulang' => '15:30',
            'jam_pulang' => '15:30',
            'max_pulang' => '18:00'
        ]);

        ConfigPotTpp::insert([
            [
                'id' => 1,
                'title' => 'Telat 1',
                'dari_meni' => 1,
                'sampai_menit' => 30,
                'persentase_potongan' => 15,
                'group' => 'masuk'
            ],
            [
                'id' => 2,
                'title' => 'Telat 2',
                'dari_meni' => 31,
                'sampai_menit' => 60,
                'persentase_potongan' => 30,
                'group' => 'masuk'
            ],
            [
                'id' => 3,
                'title' => 'Telat 3',
                'dari_meni' => 61,
                'sampai_menit' => 90,
                'persentase_potongan' => 45,
                'group' => 'masuk'
            ],
            [
                'id' => 4,
                'title' => 'Telat 4',
                'dari_meni' => 91,
                'sampai_menit' => 120,
                'persentase_potongan' => 60,
                'group' => 'masuk'
            ],
            [
                'id' => 5,
                'title' => 'Tidak Absen Pulang (PSW)',
                'dari_meni' => 0,
                'sampai_menit' => 0,
                'persentase_potongan' => 20,
                'group' => 'pulang'
            ],
            [
                'id' => 6,
                'title' => 'Izin Dengan Keterangan',
                'dari_meni' => 0,
                'sampai_menit' => 0,
                'persentase_potongan' => 50,
                'group' => 'izin'
            ],
            [
                'id' => 7,
                'title' => 'Dinas Luar',
                'dari_meni' => 0,
                'sampai_menit' => 0,
                'persentase_potongan' => 0,
                'group' => 'izin'
            ]
        ]);

        Jml_hari_kerja::insert([
            'bulan' => date('m'),
            'tahun' => date('Y'),
            'jml_hari_kerja' => 22
        ]);

        Dinas::create([
            'id' => 1,
            'nama_dinas' => 'Dinas A',
            'latitude' => -6.2088,
            'longitude' => 106.8456,
            'latitude_2' => -6.2088,
            'longitude_2' => 106.8456
        ]);

        JadwalApel::insert(
            [
                'dinas_id' => 1,
                'hari' => '1',
                'apel_pagi' => '1',
                'apel_sore' => '0',
                'jam_apel_pagi' => '08:00',
                'max_apel_pagi' => '08:15',
                'jam_apel_sore' => null,
                'max_apel_sore' => null,
                'latitude' => -6.2088,
                'longitude' => 106.8456,
                'latitude_2' => -6.2088,
                'longitude_2' => 106.8456
            ],
            [
                'dinas_id' => 1,
                'hari' => '2',
                'apel_pagi' => '1',
                'apel_sore' => '0',
                'jam_apel_pagi' => '08:00',
                'max_apel_pagi' => '08:15',
                'jam_apel_sore' => null,
                'max_apel_sore' => null,
                'latitude' => -6.2088,
                'longitude' => 106.8456,
                'latitude_2' => -6.2088,
                'longitude_2' => 106.8456
            ],
            [
                'dinas_id' => 1,
                'hari' => '3',
                'apel_pagi' => '1',
                'apel_sore' => '0',
                'jam_apel_pagi' => '08:00',
                'max_apel_pagi' => '08:15',
                'jam_apel_sore' => null,
                'max_apel_sore' => null,
                'latitude' => -6.2088,
                'longitude' => 106.8456,
                'latitude_2' => -6.2088,
                'longitude_2' => 106.8456
            ],
            [
                'dinas_id' => 1,
                'hari' => '4',
                'apel_pagi' => '1',
                'apel_sore' => '0',
                'jam_apel_pagi' => '08:00',
                'max_apel_pagi' => '08:15',
                'jam_apel_sore' => null,
                'max_apel_sore' => null,
                'latitude' => -6.2088,
                'longitude' => 106.8456,
                'latitude_2' => -6.2088,
                'longitude_2' => 106.8456
            ],
            [
                'dinas_id' => 1,
                'hari' => '5',
                'apel_pagi' => '1',
                'apel_sore' => '1',
                'jam_apel_pagi' => '08:00',
                'max_apel_pagi' => '08:15',
                'jam_apel_sore' => '16:00',
                'max_apel_sore' => '16:15',
                'latitude' => -6.2088,
                'longitude' => 106.8456,
                'latitude_2' => -6.2088,
                'longitude_2' => 106.8456
            ],
        );
    }

    public function test_clock_out_without_clock_in_should_fail()
    {
        $this->setJamPulang();

        $user = Pegawai::factory()->create([
            'tpp' => 1000000,
            'dinas_id' => 1
        ]);

        $this->assertApiException(
            fn() => (new AttendanceService())->clockOut($user),
            ErrorCode::NOT_CLOCKED_IN
        );
    }
    
    public function test_double_clock_out_should_fail()
    {
        $this->setHariKerja();

        $user = Pegawai::factory()->create([
            'tpp' => 1000000,
            'dinas_id' => 1
        ]);

        $service = new AttendanceService();

        $service->clockIn($user);
        $this->setJamPulang();
        $service->clockOut($user);

        // kedua kali
        $this->assertApiException(
            fn() => $service->clockOut($user),
            ErrorCode::ALREADY_CLOCKED_OUT
        );
    }

    public function test_clock_out_too_early_should_fail()
    {
        $this->setHariKerja();

        $user = Pegawai::factory()->create([
            'tpp' => 1000000,
            'dinas_id' => 1
        ]);

        $service = new AttendanceService();

        $service->clockIn($user);

        $this->assertApiException(
            fn() => $service->clockOut($user),
            ErrorCode::NOT_TIME_YET
        );
    }

    public function test_clock_out_hari_libur_should_fail()
    {
        $this->setHariLibur();

        $user = Pegawai::factory()->create([
            'tpp' => 1000000,
            'dinas_id' => 1
        ]);

        $this->assertApiException(
            fn() => (new AttendanceService())->clockOut($user),
            ErrorCode::NOT_CLOCKED_IN
        );
    }

    public function test_clock_out_without_jml_hari_kerja()
    {
        $this->setHariKerja();

        $user = Pegawai::factory()->create([
            'tpp' => 1000000,
            'dinas_id' => 1
        ]);

        $service = new AttendanceService();
        $service->clockIn($user);

        Jml_hari_kerja::truncate();

        $this->setJamPulang();

        $this->assertApiException(
            fn() => (new AttendanceService())->clockOut($user),
            ErrorCode::WORKDAY_NOT_CONFIGURED
        );
    }

    public function test_clock_out_after_max_jam_pulang_should_fail()
    {
        $this->setHariKerja();

        $user = Pegawai::factory()->create([
            'tpp' => 1000000,
            'dinas_id' => 1
        ]);

        $service = new AttendanceService();

        // clock in dulu
        $service->clockIn($user);

        $this->setMaxJamPulang();

        $this->assertApiException(
            fn() => $service->clockOut($user),
            ErrorCode::TOO_LATE
        );
    }

    public function test_clock_out_success()
    {
        $this->setHariKerja();

        $user = Pegawai::factory()->create([
            'tpp' => 1000000,
            'dinas_id' => 1
        ]);

        $service = new AttendanceService();

        // clock in dulu
        $service->clockIn($user);

        $this->setJamPulang();

        $result = $service->clockOut($user);

        $this->assertNotNull($result->outgoing_time);
    }
}
