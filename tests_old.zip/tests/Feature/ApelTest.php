<?php

namespace Tests\Feature;

use App\Constants\ErrorCode;
use App\Models\ConfigPotTpp;
use App\Models\Dinas;
use App\Models\JadwalApel;
use App\Models\JamAbsen;
use App\Models\Jml_hari_kerja;
use App\Models\Pegawai;
use App\Services\Attendance\AttendanceService;
use Carbon\Carbon;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class ApelTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        Cache::flush();

        JamAbsen::insert(
            [
                [
                    'id' => 1,
                    'title' => 'Senin - Kamis',
                    'min_masuk' => '07:00',
                    'jam_masuk' => '08:00',
                    'max_masuk' => '10:00',
                    'min_pulang' => '15:00',
                    'jam_pulang' => '15:00',
                    'max_pulang' => '18:00'
                ],
                [
                    'id' => 2,
                    'title' => 'Jumat',
                    'min_masuk' => '07:00',
                    'jam_masuk' => '08:00',
                    'max_masuk' => '10:00',
                    'min_pulang' => '15:30',
                    'jam_pulang' => '15:30',
                    'max_pulang' => '18:00'
                ]
            ]
        );

        ConfigPotTpp::insert([
            [
                'id' => 1,
                'title' => 'Telat 1',
                'dari_meni' => 1,
                'sampai_menit' => 30,
                'persentase_potongan' => 15,
                'group' => 'masuk'
            ],
            [
                'id' => 2,
                'title' => 'Telat 2',
                'dari_meni' => 31,
                'sampai_menit' => 60,
                'persentase_potongan' => 30,
                'group' => 'masuk'
            ],
            [
                'id' => 3,
                'title' => 'Telat 3',
                'dari_meni' => 61,
                'sampai_menit' => 90,
                'persentase_potongan' => 45,
                'group' => 'masuk'
            ],
            [
                'id' => 4,
                'title' => 'Telat 4',
                'dari_meni' => 91,
                'sampai_menit' => 120,
                'persentase_potongan' => 60,
                'group' => 'masuk'
            ],
            [
                'id' => 5,
                'title' => 'Tidak Absen Pulang (PSW)',
                'dari_meni' => 0,
                'sampai_menit' => 0,
                'persentase_potongan' => 20,
                'group' => 'pulang'
            ],
            [
                'id' => 6,
                'title' => 'Izin Dengan Keterangan',
                'dari_meni' => 0,
                'sampai_menit' => 0,
                'persentase_potongan' => 50,
                'group' => 'izin'
            ],
            [
                'id' => 7,
                'title' => 'Dinas Luar',
                'dari_meni' => 0,
                'sampai_menit' => 0,
                'persentase_potongan' => 0,
                'group' => 'izin'
            ],
            [
                'id' => 8,
                'title' => 'Tidak Apel',
                'dari_meni' => 0,
                'sampai_menit' => 0,
                'persentase_potongan' => 20,
                'group' => 'apel'
            ],
            [
                'id' => 9,
                'title' => 'Tanpa Keterangan',
                'dari_meni' => 0,
                'sampai_menit' => 0,
                'persentase_potongan' => 100,
                'group' => 'alfa'
            ]
        ]);

        Jml_hari_kerja::insert([
            'bulan' => date('m'),
            'tahun' => date('Y'),
            'jml_hari_kerja' => 22
        ]);

        Dinas::create([
            'id' => 1,
            'nama_dinas' => 'Dinas A',
            'latitude' => -6.2088,
            'longitude' => 106.8456,
            'latitude_2' => -6.2088,
            'longitude_2' => 106.8456
        ]);

        foreach ([1, 2, 3, 4, 5] as $hari) {
            JadwalApel::create([
                'dinas_id' => 1,
                'hari' => $hari,
                'apel_pagi' => '1',
                'apel_sore' => $hari == 5 ? '1' : '0',
                'jam_apel_pagi' => '08:00',
                'max_apel_pagi' => '08:15',
                'jam_apel_sore' => $hari == 5 ? '16:00' : null,
                'max_apel_sore' => $hari == 5 ? '16:15' : null,
                'latitude' => -6.2088,
                'longitude' => 106.8456,
                'latitude_2' => -6.2088,
                'longitude_2' => 106.8456,
            ]);
        }
    }

    public function test_apel_pagi_success()
    {

        $this->setHariKerja();

        $user = Pegawai::factory()->create(['tpp' => 1000000, 'dinas_id' => 1]);

        $service = new AttendanceService();

        // wajib clock in dulu
        $service->clockIn($user);

        $result = $service->apel($user, 'pagi');

        $this->assertNotNull($result->status_apel_pagi);
        $this->assertEquals('Hadir', $result->status_apel_pagi);
    }

    public function test_apel_sore_success()
    {
        // Jumat pagi
        Carbon::setTestNow('2026-03-06 08:05:00');

        $user = Pegawai::factory()->create(['tpp' => 1000000, 'dinas_id' => 1]);

        $service = new AttendanceService();

        $service->clockIn($user);

        // Jumat sore
        Carbon::setTestNow('2026-03-06 16:05:00');

        $result = $service->apel($user, 'sore');

        $this->assertEquals('Hadir', $result->status_apel_sore);
    }

    public function test_apel_without_clock_in_should_fail()
    {
        $this->setHariKerja('08:05:00');

        $user = Pegawai::factory()->create(['tpp' => 1000000, 'dinas_id' => 1]);

        $this->assertApiException(
            fn() => (new AttendanceService())->apel($user, 'pagi'),
            ErrorCode::NOT_CLOCKED_IN
        );
    }

    public function test_double_apel_pagi_should_fail()
    {
        $this->setHariKerja('08:05:00');

        $user = Pegawai::factory()->create(['tpp' => 1000000, 'dinas_id' => 1]);

        $service = new AttendanceService();

        $service->clockIn($user);
        $service->apel($user, 'pagi');

        $this->assertApiException(
            fn() => $service->apel($user, 'pagi'),
            ErrorCode::APEL_ALREADY
        );
    }

    public function test_apel_too_early_should_fail()
    {
        $this->setHariKerja('07:00:00');

        $user = Pegawai::factory()->create(['tpp' => 1000000, 'dinas_id' => 1]);

        $service = new AttendanceService();
        $service->clockIn($user);

        $this->assertApiException(
            fn() => $service->apel($user, 'pagi'),
            ErrorCode::APEL_TOO_EARLY
        );
    }

    public function test_apel_too_late_should_fail()
    {
        $this->setHariKerja('09:00:00');

        $user = Pegawai::factory()->create(['tpp' => 1000000, 'dinas_id' => 1]);

        $service = new AttendanceService();
        $service->clockIn($user);

        $this->assertApiException(
            fn() => $service->apel($user, 'pagi'),
            ErrorCode::APEL_TOO_LATE
        );
    }

    public function test_apel_not_scheduled_should_fail()
    {
        $this->setHariKerja('08:05:00');

        // hapus jadwal apel
        \App\Models\JadwalApel::truncate();

        $user = Pegawai::factory()->create(['tpp' => 1000000, 'dinas_id' => 1]);

        $service = new AttendanceService();
        $service->clockIn($user);

        $this->assertApiException(
            fn() => $service->apel($user, 'pagi'),
            ErrorCode::APEL_NOT_SCHEDULED
        );
    }

    public function test_apel_hari_libur_should_fail()
    {
        $this->setHariLibur();

        $user = Pegawai::factory()->create(['tpp' => 1000000, 'dinas_id' => 1]);

        $this->assertApiException(
            fn() => (new AttendanceService())->apel($user, 'pagi'),
            ErrorCode::WEEKEND
        );
    }

    public function test_apel_sore_not_active_should_fail()
    {
        Carbon::setTestNow('2026-03-06 08:05:00');

        // matikan apel sore
        \App\Models\JadwalApel::query()->update([
            'apel_sore' => 0
        ]);

        $user = Pegawai::factory()->create(['tpp' => 1000000, 'dinas_id' => 1]);

        $service = new AttendanceService();
        $service->clockIn($user);
        
        Carbon::setTestNow('2026-03-06 16:05:00');

        $this->assertApiException(
            fn() => $service->apel($user, 'sore'),
            ErrorCode::APEL_NOT_SCHEDULED
        );
    }

    public function test_apel_full_day()
    {
        Carbon::setTestNow('2026-03-06 08:05:00');

        $user = Pegawai::factory()->create(['tpp' => 1000000, 'dinas_id' => 1]);

        $service = new AttendanceService();

        // pagi
        $service->clockIn($user);
        $service->apel($user, 'pagi');

        // sore
        Carbon::setTestNow('2026-03-06 16:05:00');
        $result = $service->apel($user, 'sore');

        $this->assertEquals('Hadir', $result->status_apel_pagi);
        $this->assertEquals('Hadir', $result->status_apel_sore);
    }

    public function test_apel_sore_not_friday_should_fail()
    {
        // set hari SELASA
        Carbon::setTestNow('2026-03-03 08:05:00');

        $user = Pegawai::factory()->create(['tpp' => 1000000, 'dinas_id' => 1]);

        $service = new AttendanceService();

        $service->clockIn($user);

        Carbon::setTestNow('2026-03-03 16:05:00');

        $this->assertApiException(
            fn() => $service->apel($user, 'sore'),
            ErrorCode::APEL_NOT_SCHEDULED
        );
    }

    public function test_apel_sore_friday_success()
    {
        Carbon::setTestNow('2026-03-06 08:05:00');

        $user = Pegawai::factory()->create(['tpp' => 1000000, 'dinas_id' => 1]);

        $service = new AttendanceService();

        $service->clockIn($user);

        Carbon::setTestNow('2026-03-06 16:05:00');

        $result = $service->apel($user, 'sore');

        $this->assertEquals('Hadir', $result->status_apel_sore);
    }
}
