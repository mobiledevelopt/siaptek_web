-- MySQL dump 10.13  Distrib 9.2.0, for macos14.7 (arm64)
--
-- Host: localhost    Database: siaptek
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `config_potongan_tpp`
--

DROP TABLE IF EXISTS `config_potongan_tpp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config_potongan_tpp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `dari_meni` varchar(255) DEFAULT NULL,
  `sampai_menit` varchar(255) DEFAULT NULL,
  `persentase_potongan` int DEFAULT NULL,
  `group` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_potongan_tpp`
--

LOCK TABLES `config_potongan_tpp` WRITE;
/*!40000 ALTER TABLE `config_potongan_tpp` DISABLE KEYS */;
INSERT INTO `config_potongan_tpp` VALUES (1,'Telat 1','1','30',15,'masuk','2023-12-11 10:11:27','2024-10-01 13:15:28'),(2,'Telat 2','31','60',30,'masuk','2023-12-11 10:12:11','2024-10-01 13:15:32'),(3,'Telat 3','61','90',45,'masuk','2023-12-11 10:12:28','2024-10-01 13:15:34'),(4,'Telat 4','91','120',60,'masuk','2023-12-11 10:12:40','2024-10-01 13:15:39'),(5,'Tidak Absen Pulang (PSW)','0','0',20,'pulang','2023-12-11 10:13:14','2024-10-01 13:15:43'),(6,'Izin Dengan Keterangan','0','0',50,'izin','2023-12-11 10:14:02','2023-12-18 16:38:34'),(7,'Dinas Luar','0','0',0,'izin','2023-12-11 10:14:14','2023-12-18 16:38:36'),(8,'Izin Sakit','0','0',0,'izin','2023-12-11 10:14:23','2023-12-18 16:38:37'),(9,'Cuti Tahunan','0','0',0,'cuti','2023-12-11 10:15:35','2023-12-18 16:40:12'),(10,'Cuti Alasan Penting','0','0',0,'cuti','2023-12-11 10:15:53','2023-12-18 16:40:13'),(11,'Cuti Sakit','0','0',0,'cuti','2023-12-11 10:16:14','2023-12-18 16:40:14'),(12,'Cuti Melahirkan','0','0',0,'cuti','2023-12-11 10:16:26','2023-12-18 16:40:15'),(13,'Tidak Apel','0','60',20,NULL,'2023-12-11 10:16:44','2026-03-24 16:14:11'),(14,'Tanpa Keterangan','0','0',100,NULL,'2023-12-13 06:15:02','2023-12-13 06:16:08'),(15,'Izin Dengan Tugas','0','0',0,'izin','2023-12-11 10:14:02','2023-12-18 16:38:34');
/*!40000 ALTER TABLE `config_potongan_tpp` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-08  0:49:18
