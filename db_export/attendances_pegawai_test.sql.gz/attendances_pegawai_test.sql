-- MySQL dump 10.13  Distrib 9.2.0, for macos14.7 (arm64)
--
-- Host: localhost    Database: siaptek
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attendances_pegawai_test`
--

DROP TABLE IF EXISTS `attendances_pegawai_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendances_pegawai_test` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dinas_id` int DEFAULT NULL,
  `pegawai_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `date_attendance` date DEFAULT NULL,
  `incoming_time` time DEFAULT NULL,
  `outgoing_time` time DEFAULT NULL,
  `status` enum('Masuk','Dinas Luar','Tidak Masuk','izin','cuti') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'Masuk',
  `menit_telat_masuk` decimal(12,0) DEFAULT NULL,
  `total_potongan_tpp` decimal(12,0) DEFAULT '0',
  `potongan_absen_masuk` decimal(12,0) DEFAULT '0',
  `potongan_absen_pulang` decimal(12,0) DEFAULT '0',
  `potongan_tidak_masuk_kerja` decimal(12,0) DEFAULT '0',
  `potongan_tidak_apel` decimal(15,0) DEFAULT '0',
  `status_masuk` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status_pulang` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status_apel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `potongan_absen_masuk_persen` int DEFAULT '0',
  `potongan_absen_pulang_persen` int DEFAULT '0',
  `potongan_tidak_apel_persen` int DEFAULT '0',
  `potongan_tidak_masuk_kerja_persen` int DEFAULT '0',
  `ket_tidak_masuk_kerja` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `potongan_cuti` int DEFAULT '0',
  `potongan_cuti_persen` int DEFAULT '0',
  `ket_cuti` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `tunjangan_per_hari` decimal(15,0) DEFAULT '0',
  `config_potongan_tpp_id` int DEFAULT NULL,
  `tpp_diterima` decimal(15,0) DEFAULT '0',
  `foto_absen_masuk_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `foto_absen_masuk` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `foto_absen_pulang_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `foto_absen_pulang` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status_apel_pagi` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `potongan_tidak_apel_pagi_persen` int NOT NULL DEFAULT '0',
  `potongan_tidak_apel_pagi` decimal(15,0) NOT NULL DEFAULT '0',
  `foto_apel_pagi_path` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `foto_apel_pagi` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `status_apel_sore` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `potongan_tidak_apel_sore` decimal(15,0) NOT NULL DEFAULT '0',
  `potongan_tidak_apel_sore_persen` int NOT NULL DEFAULT '0',
  `foto_apel_sore_path` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `foto_apel_sore` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `anulir` tinyint(1) NOT NULL DEFAULT '0',
  `ket_anulir` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `dinas` (`dinas_id`) USING BTREE,
  KEY `pegawai` (`pegawai_id`) USING BTREE,
  KEY `config_potongan_tpp_id` (`config_potongan_tpp_id`),
  KEY `date_attendance` (`date_attendance`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendances_pegawai_test`
--

LOCK TABLES `attendances_pegawai_test` WRITE;
/*!40000 ALTER TABLE `attendances_pegawai_test` DISABLE KEYS */;
INSERT INTO `attendances_pegawai_test` VALUES (46,2,'1212321','2024-10-03','07:29:00',NULL,'Masuk',0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,NULL,0,0,NULL,'2024-10-02 19:21:29','2024-10-02 19:21:29',43478,NULL,43478,'test_persensi_pegawai/1212321_1727896889.jpg','https://siaptek.pesisirbaratkab.go.id/storage/test_persensi_pegawai/1212321_1727896889.jpg',NULL,NULL,NULL,0,0,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL);
/*!40000 ALTER TABLE `attendances_pegawai_test` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-08  0:49:18
