-- MySQL dump 10.13  Distrib 9.2.0, for macos14.7 (arm64)
--
-- Host: localhost    Database: siaptek
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `active` tinyint NOT NULL DEFAULT '1',
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `users_email_unique` (`email`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Kurnia','12302090-1635137135.jpg','admin@gmail.com','2021-10-25 04:45:35','$2y$10$qCS/3qkMxC9XSM0aIWfAn.kL65U3IlyZATtY1WwwoDsW/4eEyzWaW',1,'RdtSHz3q4E11AVFGqSa76pFpTa8pT0XLoRAfwPU1dFEuPEuR6F0z7cKywy30','2021-10-25 04:45:35','2021-10-25 04:45:35'),(2,'Jane',NULL,'jane@gmail.com','2021-11-21 09:03:09','$2y$10$qCS/3qkMxC9XSM0aIWfAn.kL65U3IlyZATtY1WwwoDsW/4eEyzWaW',1,'cHFXmefUMT','2021-11-21 09:03:09','2021-11-21 09:03:09'),(3,'Jane',NULL,'john@gmail.com','2021-11-21 09:03:09','$2y$10$OmCJldHSrMwkOfkyX676re0tDky5nUr1hhHb9KG.qmBvBxkdAnnO.',1,'xiOaLxb0cc','2021-11-21 09:03:09','2021-11-21 09:03:09'),(4,'Frank',NULL,'frank@gmail.com','2021-11-21 09:03:09','$2y$10$s8JPIPXS90zdF7swA3l4uuU3tkyxSnBcAPhMk.Bpc0xnxtcX1TM16',1,'VWmztJav1a','2021-11-21 09:03:09','2021-11-21 09:03:09'),(5,'Maria',NULL,'maria@gmail.com','2021-11-21 09:03:09','$2y$10$8j7DoYtUFAPvLqGoac940OsKPLJV3t7NQyw58VG4d7k.KOERZXoTy',1,'eRKUBwcJYy','2021-11-21 09:03:09','2021-11-21 09:03:09'),(6,'Admin Test','index-1642649667.jpeg','admintest@gmail.com','2022-01-20 03:34:27','$2y$10$B5CGrU17zkx8J3INzHjkLecZaMEsNwonUWA3j1z3EAMgfUZzC9fRa',1,'','2022-01-20 03:34:27','2022-01-20 03:34:27');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-08  0:49:20
