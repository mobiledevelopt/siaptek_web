-- MySQL dump 10.13  Distrib 9.2.0, for macos14.7 (arm64)
--
-- Host: localhost    Database: siaptek
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `menu_manager_id` bigint unsigned NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_unique` (`name`),
  KEY `permissions_menu_manager_id_foreign` (`menu_manager_id`),
  CONSTRAINT `permissions_ibfk_1` FOREIGN KEY (`menu_manager_id`) REFERENCES `menu_managers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (42,2,'Dinas List','web-dinas-list'),(43,2,'Dinas Create','web-dinas-create'),(44,2,'Dinas Edit','web-dinas-edit'),(45,2,'Dinas Delete','web-dinas-delete'),(98,3,'Jumlah Hari Kerja List','jumlah-hari-kerja-list'),(99,3,'Jumlah Hari Kerja Create','jumlah-hari-kerja-create'),(100,3,'Jumlah Hari Kerja Edit','jumlah-hari-kerja-edit'),(101,3,'Jumlah Hari Kerja Delete','jumlah-hari-kerja-delete'),(102,4,'Config TPP List','config-tpp-list'),(103,4,'Config TPP Create','config-tpp-create'),(104,4,'Config TPP Edit','config-tpp-edit'),(105,4,'Config TPP Delete','config-tpp-delete'),(106,5,'Admin List','admin-list'),(107,5,'Admin Create','admin-create'),(108,5,'Admin Edit','admin-edit'),(109,5,'Admin Delete','admin-delete'),(110,6,'Dashboard List','admin-list'),(111,7,'Data Pegawai List','pegawai-list'),(112,7,'Data Pegawai Create','pegawai-create'),(114,7,'Data Pegawai Edit','pegawai-edit'),(115,7,'Data Pegawai Delete','pegawai-delete'),(116,8,'Data Presensi List','presensi-pegawai-list'),(117,8,'Data Presensi Create','presensi-pegawai-create'),(118,8,'Data Presensi Edit','presensi-pegawai-edit'),(119,8,'Data Presensi Delete','presensi-pegawai-delete'),(120,9,'Data Pengumuman List','pengumuman-list'),(121,9,'Data Pengumuman Create','pengumuman-create'),(122,9,'Data Pengumuman Edit','pengumuman-edit'),(123,9,'Data Pengumuman Delete','pengumuman-delete'),(124,10,'Data Izin Pegawai List','web-izin-list'),(126,10,'Data Izin Pegawai Create1','web-izin-create'),(127,10,'Data Izin Pegawai Edit','web-izin-edit'),(128,10,'Data Izin Pegawai Delete','web-izin-delete'),(129,12,'Role List','roles-list'),(130,12,'Role Create','roles-create'),(131,12,'Role Edit','roles-edit'),(132,12,'Role Delete','roles-delete'),(133,11,'Reset Imei List','reset-imei-list'),(134,11,'Reset Imei Create','reset-imei-create'),(135,11,'Reset Imei Edit','reset-imei-edit'),(136,11,'Reset Imei Delete','reset-imei-delete'),(137,13,'Apel List','apel-list'),(138,13,'Apel Create','apel-create'),(139,13,'Apel Edit','apel-edit'),(140,13,'Apel Delete','apel-delete'),(141,14,'Kalendar Libur List','kalendar-libur-list'),(142,14,'Kalendar Libur Create','kalendar-libur-create'),(143,14,'Kalendar Libur Edit','kalendar-libur-edit'),(144,14,'Kalendar Libur Delete','kalendar-libur-delete'),(145,15,'Jam Absen List','jam-absen-list'),(146,15,'Jam Absen Create','jam-absen-create'),(147,15,'Jam Absen Edit','jam-absen-edit'),(148,15,'Jam Absen Delete','jam-absen-delete'),(149,16,'Radius List','radius-list'),(150,16,'radius Create','radius-create'),(151,16,'Radius Edit','radius-edit'),(152,16,'Radius Delete','radius-delete'),(153,18,'Jadwal Apel List','jadwal-apel-list'),(154,18,'Jadwal Apel Create','jadwal-apel-create'),(155,18,'Jadwal Apel Edit','jadwal-apel-edit'),(156,18,'Jadwal Apel Delete','jadwal-apel-delete');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-08  0:49:20
