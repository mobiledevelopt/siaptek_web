-- MySQL dump 10.13  Distrib 9.2.0, for macos14.7 (arm64)
--
-- Host: localhost    Database: siaptek
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pangkat_gol`
--

DROP TABLE IF EXISTS `pangkat_gol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pangkat_gol` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pangkat` varchar(255) DEFAULT NULL,
  `gol` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pangkat_gol`
--

LOCK TABLES `pangkat_gol` WRITE;
/*!40000 ALTER TABLE `pangkat_gol` DISABLE KEYS */;
INSERT INTO `pangkat_gol` VALUES (1,'juru muda','I/a','2023-12-24 05:25:18','2023-12-24 05:34:52'),(2,'juru muda tingkat I','I/b','2023-12-24 05:25:46','2023-12-24 05:34:55'),(3,'juru','I/c','2023-12-24 05:26:14','2023-12-24 05:34:57'),(4,'juru tingkat I ','I/d','2023-12-24 05:26:23','2023-12-24 05:34:58'),(5,'pengatur muda','II/a','2023-12-24 05:26:38','2023-12-24 05:35:01'),(6,'pengatur muda tingkat I','II/b','2023-12-24 05:26:49','2023-12-24 05:35:02'),(7,'pengatur','II/c','2023-12-24 05:26:57','2023-12-24 05:35:04'),(8,'pengatur tingkat I','II/d','2023-12-24 05:27:07','2023-12-24 05:35:05'),(9,'penata muda','III/a','2023-12-24 05:27:17','2023-12-24 05:35:07'),(10,'penata muda tingkat I','III/b','2023-12-24 05:27:28','2023-12-24 05:35:08'),(11,'penata','III/c','2023-12-24 05:27:36','2023-12-24 05:35:09'),(12,'penata tingkat I','III/d','2023-12-24 05:27:45','2023-12-24 05:35:12'),(13,'pembina','IV/a','2023-12-24 05:27:55','2023-12-24 05:35:17'),(14,'pembina tingkat I','IV/b','2023-12-24 05:28:04','2023-12-24 05:35:18'),(15,'pembina muda','IV/c','2023-12-24 05:28:13','2023-12-24 05:35:19'),(16,'pembina madya','IV/d','2023-12-24 05:28:22','2023-12-24 05:35:20'),(17,'pembina utama','IV/e','2023-12-24 05:28:31','2023-12-24 05:35:23');
/*!40000 ALTER TABLE `pangkat_gol` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-08  0:49:19
