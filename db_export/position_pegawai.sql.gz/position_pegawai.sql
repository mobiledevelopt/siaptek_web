-- MySQL dump 10.13  Distrib 9.2.0, for macos14.7 (arm64)
--
-- Host: localhost    Database: siaptek
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `position_pegawai`
--

DROP TABLE IF EXISTS `position_pegawai`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `position_pegawai` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `position_pegawai`
--

LOCK TABLES `position_pegawai` WRITE;
/*!40000 ALTER TABLE `position_pegawai` DISABLE KEYS */;
INSERT INTO `position_pegawai` VALUES (11,'Kepala Dinas','2023-11-06 04:39:50','2023-11-06 04:39:50'),(12,'Sekretaris','2023-11-06 04:40:37','2023-11-06 04:44:23'),(13,'Kepala Bidang Pembinaan PAUD dan Pendidikan Non Formal','2023-11-06 04:40:47','2023-11-06 04:44:54'),(14,'Kepala Bidang Pembinaan Pendidikan Dasar','2023-11-06 04:41:03','2023-11-06 04:45:12'),(15,'Kepala Bidang Pembinaan dan Pengembangan Ketenagaan','2023-11-06 04:41:31','2023-11-06 04:45:32'),(16,'Sub Koordinator Keuangan dan Aset','2023-11-06 04:42:52','2023-11-06 04:45:47'),(17,'Kabid Kebudayaan','2023-11-06 04:43:17','2023-11-06 04:45:55'),(18,'Kasubbag Umum dan Kepegawaian','2023-11-06 04:43:26','2023-11-06 04:46:14'),(19,'Sub Koordinator Perencanaan dan Pelaporan','2023-11-06 04:43:41','2023-11-06 04:46:33'),(20,'Kasi Kelembagaan, Sarpras PAUD dan Pendidikan Non Formal','2023-11-06 04:44:12','2023-11-06 04:47:01'),(21,'Kasi Peserta Didik dan Pembangunan Karakter Pendidikan Dasar','2023-11-06 04:47:24','2023-11-06 04:47:24'),(22,'Kasi PTK PAUD, Pendidikan Non Formal dan Tenaga Kebudayaan','2023-11-06 04:47:59','2023-11-06 04:47:59'),(23,'Kasi Pendidikan dan Tenaga Kependidikan Dasar','2023-11-06 04:48:12','2023-11-06 04:48:12'),(24,'Kasi Peserta Didik dan Pembangunan Karakter PAUD dan Pendidikan Non Formal','2023-11-06 04:48:35','2023-11-06 04:48:35'),(25,'Kasi Kelembagaan dan Sarpras DIKDAS','2023-11-06 04:48:49','2023-11-06 04:48:49'),(26,'Sub Koordinator Cagar Budaya dan Permuseuman','2023-11-06 04:49:06','2023-11-06 04:49:06'),(27,'Sub Koordinator Pengembangan Pendidik dan Tenaga Kependidikan','2023-11-06 04:49:27','2023-11-06 04:49:27'),(28,'Sub Koordinator Pengembangan Kurikulum, Penilaian PAUD dan Pendidikan Non Formal','2023-11-06 04:49:55','2023-11-06 04:49:55'),(29,'Sub Koordinator Sejarah dan Tradisi','2023-11-06 04:50:09','2023-11-06 04:50:09'),(30,'Analis Ekspresi Budaya Tradisional','2023-11-06 04:50:23','2023-11-06 04:50:23'),(31,'Analis Pengembangan Sarana dan Prasarana Pembelajaran','2023-11-06 04:50:44','2023-11-06 04:50:44'),(32,'Sub Koordinator Keseniaan dan Perfilmman','2023-11-06 04:51:01','2023-11-06 04:51:06'),(33,'Analis Pengembangan Pendidikan Anak Usia Dini','2023-11-06 04:51:03','2023-11-06 04:51:23'),(34,'Analis Kebutuhan Pendidik/Tenaga Kependidikan','2023-11-06 04:51:44','2023-11-06 04:51:44'),(35,'Sub Koorrdinator Pengembangan Kurikulum dan Penilaian DIKDAS','2023-11-06 04:52:21','2023-11-06 04:52:21'),(36,'Pengelola Data Pencairan Dana','2023-11-06 04:52:38','2023-11-06 04:52:38'),(37,'Analis Jabatan','2023-11-06 04:52:45','2023-11-06 04:52:45'),(38,'Bendahara Pengeluaran','2023-11-06 04:52:54','2023-11-06 04:52:54'),(39,'Pengelola Gaji','2023-11-06 04:53:02','2023-11-06 04:53:02'),(40,'Pengadministrasi Keuangan','2023-11-06 04:53:15','2023-11-06 04:53:15'),(41,'Analis Dana Rehabilitasi Fasilitas Pendidikan','2023-11-06 04:53:29','2023-11-06 04:53:29'),(42,'Pengelola Kepegawaian','2023-11-06 04:53:38','2023-11-06 04:53:38');
/*!40000 ALTER TABLE `position_pegawai` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-08  0:49:20
