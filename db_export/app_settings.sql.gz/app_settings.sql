-- MySQL dump 10.13  Distrib 9.2.0, for macos14.7 (arm64)
--
-- Host: localhost    Database: siaptek
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `app_settings`
--

DROP TABLE IF EXISTS `app_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `is_global` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `app_settings_user_id_foreign` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_settings`
--

LOCK TABLES `app_settings` WRITE;
/*!40000 ALTER TABLE `app_settings` DISABLE KEYS */;
INSERT INTO `app_settings` VALUES (1,1,'setting','layout_setting','{\"setting\": {\"footer\": {\"value\": \"default\"}, \"app_name\": {\"value\": \"Hope UI\"}, \"card_color\": {\"value\": \"card-default\"}, \"page_layout\": {\"value\": \"container-fluid\"}, \"theme_color\": {\"value\": \"theme-color-default\"}, \"sidebar_type\": {\"value\": []}, \"theme_scheme\": {\"value\": \"light\"}, \"header_banner\": {\"value\": \"default\"}, \"header_navbar\": {\"value\": \"default\"}, \"sidebar_color\": {\"value\": \"sidebar-white\"}, \"theme_font_size\": {\"value\": \"theme-fs-sm\"}, \"body_font_family\": {\"value\": null}, \"theme_transition\": {\"value\": null}, \"sidebar_menu_style\": {\"value\": \"left-bordered\"}, \"heading_font_family\": {\"value\": null}, \"theme_scheme_direction\": {\"value\": \"ltr\"}, \"theme_style_appearance\": {\"value\": []}}, \"storeKey\": \"huisetting\", \"saveLocal\": \"\"}',1,1,'2022-10-17 03:49:05','2022-10-17 03:49:05'),(5,5,'setting','layout_setting','{\"setting\": {\"footer\": {\"value\": \"default\"}, \"app_name\": {\"value\": \"Tes\"}, \"card_color\": {\"value\": \"card-default\"}, \"page_layout\": {\"value\": \"container-fluid\"}, \"theme_color\": {\"value\": \"custom\", \"colors\": {\"--{{prefix}}info\": \"#08B1BA\", \"--{{prefix}}primary\": \"#581b98\"}}, \"sidebar_type\": {\"value\": []}, \"theme_scheme\": {\"value\": \"light\"}, \"header_banner\": {\"value\": \"default\"}, \"header_navbar\": {\"value\": \"default\"}, \"sidebar_color\": {\"value\": \"sidebar-white\"}, \"theme_font_size\": {\"value\": \"theme-fs-sm\"}, \"body_font_family\": {\"value\": \"Poppins\"}, \"theme_transition\": {\"value\": \"theme-with-animation\"}, \"sidebar_menu_style\": {\"value\": \"navs-pill-all\"}, \"heading_font_family\": {\"value\": null}, \"theme_scheme_direction\": {\"value\": \"ltr\"}, \"theme_style_appearance\": {\"value\": []}}, \"storeKey\": \"huisetting\", \"saveLocal\": \"\"}',1,1,'2023-11-07 04:01:49','2023-11-07 04:01:49'),(6,6,'setting','layout_setting','{\"setting\": {\"footer\": {\"value\": \"default\"}, \"app_name\": {\"value\": \"Tes\"}, \"card_color\": {\"value\": \"card-default\"}, \"page_layout\": {\"value\": \"container-fluid\"}, \"theme_color\": {\"value\": \"custom\", \"colors\": {\"--{{prefix}}info\": \"#08B1BA\", \"--{{prefix}}primary\": \"#581b98\"}}, \"sidebar_type\": {\"value\": []}, \"theme_scheme\": {\"value\": \"light\"}, \"header_banner\": {\"value\": \"default\"}, \"header_navbar\": {\"value\": \"default\"}, \"sidebar_color\": {\"value\": \"sidebar-white\"}, \"theme_font_size\": {\"value\": \"theme-fs-sm\"}, \"body_font_family\": {\"value\": \"Poppins\"}, \"theme_transition\": {\"value\": \"theme-with-animation\"}, \"sidebar_menu_style\": {\"value\": \"navs-pill-all\"}, \"heading_font_family\": {\"value\": null}, \"theme_scheme_direction\": {\"value\": \"ltr\"}, \"theme_style_appearance\": {\"value\": []}}, \"storeKey\": \"huisetting\", \"saveLocal\": \"\"}',1,1,'2023-11-26 12:56:22','2023-11-26 12:56:22'),(7,7,'setting','layout_setting','{\"setting\": {\"footer\": {\"value\": \"default\"}, \"app_name\": {\"value\": \"Tes\"}, \"card_color\": {\"value\": \"card-default\"}, \"page_layout\": {\"value\": \"container-fluid\"}, \"theme_color\": {\"value\": \"custom\", \"colors\": {\"--{{prefix}}info\": \"#08B1BA\", \"--{{prefix}}primary\": \"#581b98\"}}, \"sidebar_type\": {\"value\": []}, \"theme_scheme\": {\"value\": \"light\"}, \"header_banner\": {\"value\": \"default\"}, \"header_navbar\": {\"value\": \"default\"}, \"sidebar_color\": {\"value\": \"sidebar-white\"}, \"theme_font_size\": {\"value\": \"theme-fs-sm\"}, \"body_font_family\": {\"value\": \"Poppins\"}, \"theme_transition\": {\"value\": \"theme-with-animation\"}, \"sidebar_menu_style\": {\"value\": \"navs-pill-all\"}, \"heading_font_family\": {\"value\": null}, \"theme_scheme_direction\": {\"value\": \"ltr\"}, \"theme_style_appearance\": {\"value\": []}}, \"storeKey\": \"huisetting\", \"saveLocal\": \"\"}',1,1,'2023-12-05 09:45:54','2023-12-05 09:45:54');
/*!40000 ALTER TABLE `app_settings` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-08  0:49:14
