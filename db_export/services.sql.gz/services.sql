-- MySQL dump 10.13  Distrib 9.2.0, for macos14.7 (arm64)
--
-- Host: localhost    Database: siaptek
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `services` (
  `id` int NOT NULL AUTO_INCREMENT,
  `service_type_id` int DEFAULT NULL,
  `service_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `note` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `activated` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `services_ibfk_1` (`service_type_id`) USING BTREE,
  CONSTRAINT `services_ibfk_1` FOREIGN KEY (`service_type_id`) REFERENCES `services_type` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES (3,3,'Legalisir Ijazah','Jangka waktu pelayanan 1 hari kerja',1,'2023-09-24 14:54:17','2023-09-24 14:55:29'),(4,3,'Surat Keterangan Pengganti Ijazah (SKPI)','Jangka waktu pelayanan 1 hari kerja',1,'2023-09-24 22:39:03','2023-09-25 09:29:05'),(5,3,'Surat Keterangan Kesalahan Penulisan Ijazah','Jangka waktu pelayanan 1 hari kerja',1,'2023-09-25 00:51:55','2023-09-25 09:29:23'),(6,3,'Pengajuan Cuti Bersalin dan Cuti Haji/Umroh PNS','Jangka waktu pelayanan 1 hari kerja',1,'2023-09-25 09:23:29','2023-09-25 09:30:15'),(7,3,'Pengajuan pensiun Guru PNS','Jangka waktu pelayanan 1 hari kerja',1,'2023-09-25 09:26:36','2023-09-25 09:30:30'),(8,3,'Pengantar Izin Belajar','Jangka waktu pelayanan 1 hari kerja',1,'2023-09-25 09:26:52','2023-09-25 09:32:19'),(9,3,'Penerimaan Siswa Magang','Jangka waktu pelayanan 1 hari kerja',1,'2023-09-25 09:27:08','2023-09-25 09:31:45'),(10,3,'Pengajuan Pindah Rayon','Jangka waktu pelayanan 1 hari kerja',1,'2023-09-25 09:48:04','2023-09-28 19:52:33'),(11,4,'Rekomendasi Izin Operasional TK/PAUD/PKBM/LKP','Jangka waktu pelayanan 1 hari kerja',1,'2023-09-25 09:48:42','2023-09-26 05:38:59'),(12,4,'Rekomendasi Izin Operasional SD/SMP','Jangka waktu pelayanan 1 hari kerja',1,'2023-09-25 09:49:12','2023-09-26 05:39:09'),(13,4,'Pengajuan Mutasi Guru PNS','Jangka waktu pelayanan 1 hari kerja',1,'2023-09-25 09:49:32','2023-09-26 12:49:10'),(14,4,'Rekomendasi Dana BOS','Jangka waktu pelayanan 1 hari kerja',1,'2023-09-25 09:49:49','2023-09-26 05:38:50'),(15,4,'Pengajuan DUPAK/Kenaikan Pangkat Guru PNS','Jangka waktu pelayanan 1 hari kerja',1,'2023-09-25 09:50:23','2023-09-26 12:49:13'),(16,4,'Pengajuan SK Funsional Pertama Guru','Jangka waktu pelayanan 1 hari kerja',1,'2023-09-25 09:50:55','2023-09-26 05:38:15'),(17,4,'Pembuatan Izin Sanggar','Jangka waktu pelayanan 1 hari kerja',1,'2023-09-25 09:51:11','2023-09-26 05:49:01'),(18,5,'Update Data Dapodik','Jangka waktu pelayanan 1 hari kerja',1,'2023-09-25 09:51:51','2023-09-26 05:42:10'),(21,5,'Pengajuan Nomor Pokok Sekolah Nasional (NPSN)','Jangka waktu pelayanan 1 hari kerja',1,'2023-09-26 02:02:08','2023-09-26 12:45:32');
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-08  0:49:20
