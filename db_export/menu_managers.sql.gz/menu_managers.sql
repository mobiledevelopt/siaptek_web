-- MySQL dump 10.13  Distrib 9.2.0, for macos14.7 (arm64)
--
-- Host: localhost    Database: siaptek
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `menu_managers`
--

DROP TABLE IF EXISTS `menu_managers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_managers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` tinyint NOT NULL DEFAULT '0',
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `path_url` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('module','header','line','static') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `menu_managers_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_managers`
--

LOCK TABLES `menu_managers` WRITE;
/*!40000 ALTER TABLE `menu_managers` DISABLE KEYS */;
INSERT INTO `menu_managers` VALUES (1,0,'Master Data',NULL,NULL,'fa-duotone fa-database','static',NULL,1),(2,1,'Dinas','users','/web-dinas',NULL,'module',NULL,2),(3,1,'Jumlah Hari Kerja','jumlah-hari-kerja','/jumlah-hari-kerja',NULL,'module',NULL,3),(4,1,'Config TPP','config-tpp','/config-tpp',NULL,'module',NULL,4),(5,1,'Admin','admin','/admin',NULL,'module',NULL,7),(6,0,'Dashboard','home','/home','fa-duotone fa-grid-horizontal','module',NULL,6),(7,0,'Data Pegawai','pegawai','/pegawai','fa-sharp fa-solid fa-user-tie','module',NULL,7),(8,0,'Data Presensi','presensi-pegawai','/presensi-pegawai','fa-duotone fa-clipboard-user','module',NULL,8),(9,0,'Data Pengumuman','pengumuman','/web-pengumuman','fa-duotone fa-megaphone','module',NULL,9),(10,0,'Data Izin Pegawai','izin','/web-izin','fa-solid fa-envelope-open-text','module',NULL,10),(11,0,'Reset imei','reset-imei','/reset-imei','fa-solid fa-mobile-notch','module',NULL,11),(12,1,'Roles','role','/roles',NULL,'module',NULL,6),(13,0,'Data Apel','apel','/web-apel','fa-duotone fa-clipboard','module',NULL,11),(14,0,'Kalendar Libur','kalendar-libur','/kalendar-libur','fa-regular fa-calendar-day','module',NULL,11),(15,1,'Jam Presensi','jam-absen','/jam-absen',NULL,'module',NULL,5),(16,1,'Radius Presensi','radius','/radius',NULL,'module',NULL,7),(17,1,'Jam Apel','jam-apel','/jam-apel',NULL,'module',NULL,5),(18,1,'Jadwal Apel','jadwal-apel','/jadwal-apel',NULL,'module',NULL,5);
/*!40000 ALTER TABLE `menu_managers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-08  0:49:19
